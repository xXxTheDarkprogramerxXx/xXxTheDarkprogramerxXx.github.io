Hello PS3 Scene

Today I Bring You A Little Tool For PS3 XMB Modifications

So this tool basicly patches your xmb Categories And Your Startup Screen Message
================================================================
Remember To Spesify Your Firmware Version to prefent softbricks
=================================================================
Also if a softbrick accours Just Re-install Your Current CFW
=================================================================
Have Fun 

xDPx

Thanks To KaKaRoTo's for the compiler
Also Thanks To TizzyT,Starmelter,sandungas,MBLK
and all the other guys for there help


====Change Log=====
=====  V2.00 ======
Added Language Selector
Did a bit of code cleanup
=====  V1.00 ======
Public Release
Added Firmware Selector
Added Ability to add Custom RcoFiles For Extracts
==== V0.02A====
Fixed Windows Xp Color Error 
Thanks StarMelter,sandungas and KTD
==== V0.02 ====
Added Home
Added Compiler
==== v0.01 ====
beta Testers
Added Startscreen Changer
Added Category Name Changer






